// 📁 index.js
require('dotenv').config();
const fs = require('fs');
const { Client, Collection, GatewayIntentBits, Partials, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField, AttachmentBuilder } = require('discord.js');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel]
});

client.commands = new Collection();

const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  client.commands.set(command.data.name, command);
}

client.once('ready', () => {
  console.log(`✅ Bot attivo come ${client.user.tag}`);
});

client.on('interactionCreate', async interaction => {
  if (interaction.isChatInputCommand()) {
    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    try {
      await command.execute(interaction);
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: 'Errore nell\'esecuzione del comando.', ephemeral: true });
    }
  } else if (interaction.isButton()) {
    if (interaction.customId === 'open_ticket') {
      const channel = await interaction.guild.channels.create({
        name: `ticket-${interaction.user.username}`,
        type: 0,
        parent: process.env.TICKET_CATEGORY_ID,
        permissionOverwrites: [
          {
            id: interaction.guild.roles.everyone.id,
            deny: [PermissionsBitField.Flags.ViewChannel]
          },
          {
            id: interaction.user.id,
            allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages]
          },
          {
            id: process.env.STAFF_ROLE_ID,
            allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages]
          }
        ]
      });

      const closeButton = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('close_ticket')
          .setLabel('🔒 Chiudi Ticket')
          .setStyle(ButtonStyle.Danger)
      );

      await channel.send({ content: `🎟️ Ticket aperto da ${interaction.user}`, components: [closeButton] });
      await interaction.reply({ content: '✅ Ticket creato!', ephemeral: true });
    } else if (interaction.customId === 'close_ticket') {
      const messages = await interaction.channel.messages.fetch({ limit: 100 });
      const content = messages.map(m => `[${m.author.tag}] ${m.content}`).reverse().join('\n');
      const buffer = Buffer.from(content, 'utf-8');
      const transcript = new AttachmentBuilder(buffer, { name: 'transcript.txt' });

      const logChannel = interaction.guild.channels.cache.find(ch => ch.name === 'ticket-log');
      if (logChannel) await logChannel.send({ content: `📄 Transcript del ticket chiuso da ${interaction.user.tag}`, files: [transcript] });

      await interaction.reply({ content: '🗃️ Transcript salvato. Ticket verrà chiuso.', ephemeral: true });
      setTimeout(() => interaction.channel.delete(), 5000);
    }
  }
});

client.on('guildMemberAdd', member => {
  const welcomeChannel = member.guild.systemChannel;
  if (welcomeChannel) welcomeChannel.send(`👋 Benvenuto ${member.user.tag} su **${member.guild.name}**!`);
});

client.on('messageDelete', msg => {
  if (!msg.guild || msg.author.bot) return;
  const log = `[🗑️] Messaggio eliminato in #${msg.channel.name} da ${msg.author.tag}: ${msg.content}`;
  console.log(log);
});

client.on('messageUpdate', (oldMsg, newMsg) => {
  if (!newMsg.guild || newMsg.author.bot) return;
  const log = `[✏️] Messaggio modificato in #${newMsg.channel.name} da ${newMsg.author.tag}:
Prima: ${oldMsg.content}
Dopo: ${newMsg.content}`;
  console.log(log);
});

client.login(process.env.TOKEN);
