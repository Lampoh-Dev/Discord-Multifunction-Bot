const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Avvisa un utente')
    .addUserOption(opt => opt.setName('utente').setDescription('Utente da avvisare').setRequired(true))
    .addStringOption(opt => opt.setName('motivo').setDescription('Motivo dell\'avviso')),
  async execute(interaction) {
    const user = interaction.options.getUser('utente');
    const motivo = interaction.options.getString('motivo') || 'Nessun motivo';

    console.log(`[⚠️ AVVISO] ${user.tag} avvisato da ${interaction.user.tag} - Motivo: ${motivo}`);
    await interaction.reply(`⚠️ ${user.tag} è stato avvisato. Motivo: ${motivo}`);
  }
};
