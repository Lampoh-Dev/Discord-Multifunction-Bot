const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Banna un membro')
    .addUserOption(opt => opt.setName('utente').setDescription('Utente da bannare').setRequired(true))
    .addStringOption(opt => opt.setName('motivo').setDescription('Motivo del ban')),
  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
      return interaction.reply({ content: '❌ Non hai i permessi per bannare.', ephemeral: true });
    }

    const user = interaction.options.getUser('utente');
    const motivo = interaction.options.getString('motivo') || 'Nessun motivo';

    try {
      await interaction.guild.members.ban(user, { reason: motivo });
      await interaction.reply(`✅ ${user.tag} è stato bannato. 🛑 Motivo: ${motivo}`);
    } catch (err) {
      await interaction.reply({ content: '❌ Errore nel bannare l\'utente.', ephemeral: true });
    }
  }
};
