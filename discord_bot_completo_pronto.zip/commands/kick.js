const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Espelle un membro')
    .addUserOption(opt => opt.setName('utente').setDescription('Utente da espellere').setRequired(true))
    .addStringOption(opt => opt.setName('motivo').setDescription('Motivo dell\'espulsione')),
  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.KickMembers)) {
      return interaction.reply({ content: '❌ Non hai i permessi per espellere.', ephemeral: true });
    }

    const user = interaction.options.getUser('utente');
    const motivo = interaction.options.getString('motivo') || 'Nessun motivo';

    try {
      const member = await interaction.guild.members.fetch(user.id);
      await member.kick(motivo);
      await interaction.reply(`✅ ${user.tag} è stato espulso. 🛑 Motivo: ${motivo}`);
    } catch (err) {
      await interaction.reply({ content: '❌ Errore nel espellere l\'utente.', ephemeral: true });
    }
  }
};
