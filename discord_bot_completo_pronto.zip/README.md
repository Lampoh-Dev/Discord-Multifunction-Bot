# 🤖 Discord Moderation Bot

Bot completo per server Discord:

- ✅ Ticket con pannello, categoria e ruolo staff
- 🗃️ Transcript dei ticket salvati in `ticket-log`
- 🛠️ Comandi moderazione (`/ban`, `/kick`, `/warn`)
- 👋 Messaggi benvenuto e log messaggi modificati/eliminati

## 🛠️ Setup

1. Clona il progetto:
   ```bash
   git clone <repo>
   cd <repo>
   ```

2. Installa le dipendenze:
   ```bash
   npm install
   ```

3. Rinomina `.env.example` in `.env` e aggiungi:
   ```
   TOKEN=il_tuo_token
   CLIENT_ID=tuo_client_id
   GUILD_ID=tuo_guild_id
   STAFF_ROLE_ID=ruolo_staff
   TICKET_CATEGORY_ID=categoria_ticket
   ```

4. Avvia il bot:
   ```bash
   npm start
   ```

### 🚀 Hosting consigliato
- Railway (Node.js project)
- Replit
- GitHub + Railway

---
Creato con ❤️ da ChatGPT
